package com.flipkart.mc;

public class BowlingAlleyContants {
    public static String SCORE_DELIMITER_LEFT = "{";
    public static String SCORE_DELIMITER_RIGHT = "}";
    public static String CHANCE_SCORE_DELIMITER_RIGHT = ",";
    public static Integer TOTAL_CHANCES_PER_ROUND = 2;
    public static Integer TOTAL_ROUNDS = 3;
    public static Integer MAX_BOWLING_PINS = 10;
    public static Integer STRIKE_BONUS = 10;
    public static Integer SPARE_BONUS = 5;
    public static Integer EXTRA_CHANCES_LAST_ROUND = 0;
}
