package com.flipkart.mc;


import java.util.Scanner;

import static com.flipkart.mc.BowlingAlleyContants.*;

public class BowlingAlleyManager {

    private static ScoreBoard scoreBoard;
    private static Integer totalPlayers;

    // Assuming arg[1] is N - total number of players
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        totalPlayers = scanner.nextInt();
        init();
        play();
        addBonuses();
        displayFinalStandings();

    }

    private static void addBonuses() {
        for(Player p : scoreBoard.getPlayers()){
            for(Score score : p.getScores()){
                if(MAX_BOWLING_PINS.equals(score.getTotalRoundScore())){
                    if(TOTAL_CHANCES_PER_ROUND > score.getChanceScores().size()){
                        // strike
                        p.addBonus(STRIKE_BONUS);
                    }
                    else{
                        // spare
                        p.addBonus(SPARE_BONUS);
                    }
                }
            }
        }
    }

    private static void displayFinalStandings() {
        scoreBoard.rankPlayers();
        scoreBoard.displayRankingWise();
        scoreBoard.displayScorebaord();
    }

    public static void init(){
        scoreBoard = new ScoreBoard(totalPlayers);
    }
    public static void play(){
        for (int i = 0; i < TOTAL_ROUNDS; i++) {
            for(int j = 0;j < totalPlayers;j++ ){
                System.out.println("Enter score for per chance for round : " + Integer.toString(i+1)  + " & player : " + Integer.toString(j+1) );
                Player currentPlayer = scoreBoard.getPlayers().get(j);
                Integer totalInRound = 0;
                for (int k = 0; k < TOTAL_CHANCES_PER_ROUND ; k++) {
                    Scanner scanner = new Scanner(System.in);
                    Integer chanceScore = scanner.nextInt();
                    Score s = new Score(i);
                    totalInRound += chanceScore;
                    s.addChanceScore(chanceScore);
                    currentPlayer.addScore(s);
                    if(MAX_BOWLING_PINS.equals(chanceScore)) {
                        break;
                    }
                }

                if(MAX_BOWLING_PINS.equals(totalInRound) && (TOTAL_ROUNDS-1)==i ){
                    for (int k = 0; k < EXTRA_CHANCES_LAST_ROUND ; k++) {
                        Scanner scanner = new Scanner(System.in);
                        Integer chanceScore = scanner.nextInt();
                        Score s = new Score(i);
                        totalInRound += chanceScore;
                        s.addChanceScore(chanceScore);
                        currentPlayer.addScore(s);
                    }
                }
            }
        }
    }
}
